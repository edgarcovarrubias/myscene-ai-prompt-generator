import React, { useState } from 'react';
import { Copy } from "lucide-react";

export default function PromptGenerator() {
  const [formData, setFormData] = useState({
    render_type: '',
    subject: '',
    environment: '',
    style: '',
    camera: '',
    clothing: '',
    lighting: '',
    effects: '',
    mood: '',
  });

  const [jsonOutput, setJsonOutput] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const generateJSON = () => {
    const json = {
      render_type: formData.render_type,
      subject: {
        type: formData.subject
      },
      environment: {
        setting: formData.environment
      },
      style: {
        genre: formData.style,
        mood: formData.mood
      },
      camera_settings: {
        lens: formData.camera
      },
      clothing: formData.clothing,
      lighting: formData.lighting,
      special_effects: formData.effects
    };
    setJsonOutput(JSON.stringify(json, null, 2));
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(jsonOutput);
  };

  const downloadJSON = () => {
    const blob = new Blob([jsonOutput], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'prompt.json';
    link.click();
  };

  const downloadTXT = () => {
    const blob = new Blob([jsonOutput], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'prompt.txt';
    link.click();
  };

  return (
    <div className="p-6 space-y-6 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold text-center">MyScene AI — Prompt Generator</h1>

      <div className="shadow-xl rounded-2xl border p-6 grid gap-4">
        <input name="render_type" placeholder="🎬 Render Type" className="border rounded p-2" value={formData.render_type} onChange={handleChange} />
        <input name="subject" placeholder="🧍 Subject Type" className="border rounded p-2" value={formData.subject} onChange={handleChange} />
        <input name="environment" placeholder="🌋 Environment" className="border rounded p-2" value={formData.environment} onChange={handleChange} />
        <input name="style" placeholder="🎨 Style Genre" className="border rounded p-2" value={formData.style} onChange={handleChange} />
        <input name="mood" placeholder="🔴 Mood (NEW)" className="border border-red-500 rounded p-2" value={formData.mood} onChange={handleChange} />
        <input name="camera" placeholder="📸 Camera Lens" className="border rounded p-2" value={formData.camera} onChange={handleChange} />
        <input name="clothing" placeholder="🔴 Clothing (NEW)" className="border border-red-500 rounded p-2" value={formData.clothing} onChange={handleChange} />
        <input name="lighting" placeholder="🔴 Lighting (NEW)" className="border border-red-500 rounded p-2" value={formData.lighting} onChange={handleChange} />
        <input name="effects" placeholder="🔴 Special Effects (NEW)" className="border border-red-500 rounded p-2" value={formData.effects} onChange={handleChange} />
        <button className="bg-emerald-600 text-white rounded p-3 font-semibold" onClick={generateJSON}>🚀 Generate JSON Prompt</button>
      </div>

      {jsonOutput && (
        <div className="shadow-lg border-2 border-emerald-600 rounded p-4 space-y-2">
          <h2 className="text-xl font-semibold">🎯 Generated Prompt</h2>
          <textarea rows={18} value={jsonOutput} readOnly className="text-sm font-mono w-full p-2 rounded border" />
          <div className="flex gap-2">
            <button className="flex items-center gap-1 bg-blue-600 text-white rounded p-2" onClick={copyToClipboard}><Copy className="w-4 h-4" /> Copy</button>
            <button className="bg-yellow-500 rounded p-2 font-semibold" onClick={downloadTXT}>⬇️ Download .txt</button>
            <button className="bg-green-600 text-white rounded p-2 font-semibold" onClick={downloadJSON}>⬇️ Download .json</button>
          </div>
        </div>
      )}
    </div>
  );
}